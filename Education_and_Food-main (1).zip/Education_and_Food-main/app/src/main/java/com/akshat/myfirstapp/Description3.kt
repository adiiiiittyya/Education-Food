package com.akshat.myfirstapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Description3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description3)
    }
}